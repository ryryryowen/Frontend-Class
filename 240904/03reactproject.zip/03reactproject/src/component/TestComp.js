import React, { useReducer } from "react";

const TestComp = () => {
  return (
    <div>
      <h4>테스트 컴포넌트</h4>
      <div>
        <bold>0</bold>
      </div>
      <div>
        <button>+</button>
        <button>-</button>
      </div>
    </div>
  );
};

export default TestComp;
